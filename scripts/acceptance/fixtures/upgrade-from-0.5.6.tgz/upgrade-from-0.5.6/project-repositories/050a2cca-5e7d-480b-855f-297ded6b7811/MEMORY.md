# Project memory

This is the canonical, curated memory for the research Project. Keep entries concise and evidence-linked; compact superseded entries instead of creating a second memory authority.

## Goals

- Establish the Project's measurable research goals.

## Decisions

<!-- YYYY-MM-DD | decision | rationale | evidence/commit -->

## Findings

<!-- YYYY-MM-DD | finding | confidence | evidence path -->

## Constraints

<!-- stable constraints that affect research execution -->

## Open questions

<!-- unresolved questions and the next evidence needed -->
