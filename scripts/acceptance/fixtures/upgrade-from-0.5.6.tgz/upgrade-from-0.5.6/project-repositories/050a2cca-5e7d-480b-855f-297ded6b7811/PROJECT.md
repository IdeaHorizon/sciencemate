# Smoke

Git-native scientific research project.

## Research objective

Define the falsifiable objective for this Project.

## Scope and constraints

Record scientific, ethical, budget, and time constraints.

## Acceptance criteria

Describe the evidence required to consider the Project complete.
