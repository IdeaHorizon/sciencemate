## Personal Research Settings
- Response language: auto
- Citation style: author_year
- Evidence standard: balanced
